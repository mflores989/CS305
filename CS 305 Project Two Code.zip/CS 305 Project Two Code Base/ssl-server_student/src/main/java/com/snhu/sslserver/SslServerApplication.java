package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
	
	@GetMapping("/hash")
	public String getHash() throws NoSuchAlgorithmException {
		String data = "Maria Flores - Artemis Financial CS305 Project Two";
		
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		
		byte[] hashBytes = digest.digest(
				data.getBytes(StandardCharsets.UTF_8));
		
		StringBuilder checksum = new StringBuilder();
		
		for (byte b : hashBytes) {
			checksum.append(String.format("%02x", b & 0xff));
		}
		
		return "Original Data: " + data + "\nSHA-256 Checksum: " + checksum.toString();
	}
}